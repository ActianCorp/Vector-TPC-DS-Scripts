CREATE TABLE reason (
    r_reason_sk integer NOT NULL,
    r_reason_id character(16) NOT NULL,
    r_reason_desc character(100)
)
